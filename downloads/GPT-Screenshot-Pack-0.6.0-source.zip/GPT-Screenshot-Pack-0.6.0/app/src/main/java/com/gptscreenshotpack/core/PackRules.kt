package com.gptscreenshotpack.core

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt
import kotlin.math.roundToLong

enum class OutputFormat(val extension: String) { HEIC("heic"), PNG("png"), JPEG("jpg") }
// Keep REDUCED's persisted name for the existing scale A preference.
enum class ResolutionMode { ORIGINAL, REDUCED, SCALE_B, WIDTH }

data class PackSettings(
    val scalePercent: Int = 100,
    val format: OutputFormat = OutputFormat.HEIC,
    val heicQuality: Int = 85,
    val jpegQuality: Int = 95,
    val resolutionMode: ResolutionMode = ResolutionMode.ORIGINAL,
    val scalePercentB: Int = 75,
    val targetWidth: Int = 1080,
) {
    init {
        require(scalePercent in 25..100)
        require(scalePercentB in 25..100)
        require(targetWidth > 0)
        require(heicQuality in 1..100 && jpegQuality in 1..100)
    }
    val quality: Int get() = if (format == OutputFormat.JPEG) jpegQuality else heicQuality
    // Width mode has a different effective percentage for each input image.
    val effectiveScalePercent: Int? get() = when (resolutionMode) {
        ResolutionMode.ORIGINAL -> 100
        ResolutionMode.REDUCED -> scalePercent
        ResolutionMode.SCALE_B -> scalePercentB
        ResolutionMode.WIDTH -> null
    }
    fun targetDimensions(input: Dimensions): Dimensions = when (resolutionMode) {
        ResolutionMode.ORIGINAL -> input
        ResolutionMode.REDUCED -> input.scaled(scalePercent)
        ResolutionMode.SCALE_B -> input.scaled(scalePercentB)
        ResolutionMode.WIDTH -> input.withWidth(targetWidth)
    }
}

object PackPresets {
    val scales = listOf(33, 50, 60, 67, 75, 100)
    val qualities = listOf(50, 75, 85, 90, 95, 100)
}

data class Dimensions(val width: Int, val height: Int) {
    init { require(width > 0 && height > 0) }
    fun withWidth(targetWidth: Int): Dimensions {
        require(targetWidth > 0) { "宽度须为正整数（px）" }
        val targetHeight = (height * (targetWidth.toDouble() / width)).roundToLong().coerceAtLeast(1)
        require(targetHeight <= Int.MAX_VALUE) { "按指定宽度计算的高度过大，请减小宽度" }
        return Dimensions(targetWidth, targetHeight.toInt())
    }
    fun scaled(percent: Int): Dimensions {
        require(percent in 25..100)
        return Dimensions((width.toLong() * percent / 100.0).roundToInt().coerceAtLeast(1),
            (height.toLong() * percent / 100.0).roundToInt().coerceAtLeast(1))
    }
}

data class Tile(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

object Slicing {
    const val SAFE_LIMIT = 16384
    private const val TILE_TARGET = 12000
    fun plan(size: Dimensions): List<Tile> {
        fun edges(length: Int): List<Int> {
            val count = if (length <= SAFE_LIMIT) 1 else ((length.toLong() + TILE_TARGET - 1) / TILE_TARGET).toInt()
            require(count <= 10000) { "图片尺寸过大" }
            return (0..count).map { (length.toLong() * it / count).toInt() }
        }
        val xs = edges(size.width)
        val ys = edges(size.height)
        require((xs.size - 1).toLong() * (ys.size - 1) <= 10000) { "切片数量过多" }
        return ys.zipWithNext().flatMap { (top, bottom) ->
            xs.zipWithNext().map { (left, right) -> Tile(left, top, right, bottom) }
        }
    }
}

class OutputNames {
    private val used = mutableSetOf<String>()
    private val usedBases = mutableSetOf<String>()
    fun allocate(original: String, format: OutputFormat, count: Int): List<String> {
        require(count > 0)
        val safe = original.map { if (it == '/' || it == '\\' || it.code < 32 || it.code == 127) '_' else it }.joinToString("")
        val dot = safe.lastIndexOf('.')
        val stem = (if (dot > 0) safe.substring(0, dot) else safe).ifBlank { "image" }
        // Leave room for extension and collision/slice suffix on typical filesystems.
        require(stem.toByteArray(Charsets.UTF_8).size <= 210) { "文件名主体过长，无法安全保留" }
        var copy = 1
        while (true) {
            val base = "resized_$stem" + if (copy == 1) "" else "_copy$copy"
            val names = (1..count).map { base + (if (count == 1) "" else "_$it") + ".${format.extension}" }
            if ("$base.${format.extension}" !in usedBases && names.none { it in used }) {
                used.addAll(names)
                usedBases.add("$base.${format.extension}")
                return names
            }
            copy++
        }
    }
}

data class ZipImage(val name: String, val open: () -> InputStream)

object ImageZip {
    fun write(images: List<File>, destination: File, checkpoint: () -> Unit = {}) {
        require(images.all { it.isFile })
        try {
            destination.outputStream().buffered().use { stream ->
                writeStreams(images.map { file -> ZipImage(file.name) { file.inputStream() } }, stream, checkpoint)
            }
        } catch (e: Throwable) {
            destination.delete()
            throw e
        }
    }

    /** Two bounded-memory passes: size/CRC first, then DEFLATED at BEST_SPEED. */
    fun writeStreams(images: List<ZipImage>, destination: OutputStream, checkpoint: () -> Unit = {}) {
        require(images.isNotEmpty()) { "不生成空 ZIP" }
        require(images.all { it.name.substringAfterLast('.', "").lowercase() in setOf("heic", "png", "jpg") &&
            '/' !in it.name && '\\' !in it.name })
        require(images.map { it.name }.distinct().size == images.size)
        ZipOutputStream(destination).use { zip ->
            zip.setLevel(Deflater.BEST_SPEED)
            val buffer = ByteArray(64 * 1024)
            for (image in images) {
                checkpoint()
                val crc = CRC32()
                var size = 0L
                image.open().use { input ->
                    while (true) {
                        checkpoint()
                        val n = input.read(buffer)
                        if (n < 0) break
                        crc.update(buffer, 0, n)
                        size = Math.addExact(size, n.toLong())
                    }
                }
                val entry = ZipEntry(image.name).apply {
                    method = ZipEntry.DEFLATED
                    this.size = size
                    this.crc = crc.value
                }
                zip.putNextEntry(entry)
                val actualCrc = CRC32()
                var actualSize = 0L
                image.open().use { input ->
                    while (true) {
                        checkpoint()
                        val n = input.read(buffer)
                        if (n < 0) break
                        zip.write(buffer, 0, n)
                        actualCrc.update(buffer, 0, n)
                        actualSize = Math.addExact(actualSize, n.toLong())
                    }
                }
                // DEFLATED can emit a data descriptor instead of validating pre-set metadata.
                if (actualSize != size || actualCrc.value != crc.value) throw ZipException("图片在校验和打包期间发生变化")
                zip.closeEntry() // The writer determines the actual compressed size.
            }
        }
    }
}
