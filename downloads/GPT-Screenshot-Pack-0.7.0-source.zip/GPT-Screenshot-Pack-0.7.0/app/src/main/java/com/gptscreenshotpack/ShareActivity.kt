package com.gptscreenshotpack

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.currentStateAsState
import com.gptscreenshotpack.core.OutputContainer
import com.gptscreenshotpack.core.OutputFormat
import com.gptscreenshotpack.core.ResolutionMode

internal fun sharedImages(intent: Intent): List<Uri> {
    if (intent.action !in setOf(Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE)) return emptyList()
    val streams = if (intent.action == Intent.ACTION_SEND_MULTIPLE)
        IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
    else listOfNotNull(IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java))
    return streams.ifEmpty {
        intent.clipData?.let { clip -> (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri } }.orEmpty()
    }
}

class ShareActivity : ComponentActivity() {
    private val model: ShareViewModel by viewModels()
    private val storagePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        model.storagePermissionResult(it)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        model.prepare(sharedImages(intent))
        setContent {
            MaterialTheme {
                val state by model.state.collectAsStateWithLifecycle()
                val lifecycleState by lifecycle.currentStateAsState()
                BackHandler { model.close() }
                LaunchedEffect(state.askStoragePermission) {
                    if (state.askStoragePermission) {
                        model.permissionDialogLaunching()
                        storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                }
                LaunchedEffect(state.phase, lifecycleState) {
                    if (lifecycleState.isAtLeast(Lifecycle.State.RESUMED)) {
                        if (state.phase == SharePhase.SAVED) {
                            val result = checkNotNull(state.result)
                            val output = checkNotNull(result.output)
                            val details = if (result.errors.isNotEmpty() || result.notes.isNotEmpty())
                                "\n成功 ${result.successCount}，失败 ${result.errors.size}" +
                                    if (result.notes.any { "回退 PNG" in it }) "；部分 HEIC 已回退 PNG" else "" else ""
                            Toast.makeText(this@ShareActivity, "已保存：${output.directory}${output.name}$details", Toast.LENGTH_LONG).show()
                            finish() // Do not open a chooser or remove the source application's task.
                        } else if (state.phase == SharePhase.CLOSED) finish()
                    }
                }
                if (state.phase !in setOf(SharePhase.SAVED, SharePhase.CLOSED)) ShareDialog(state, model)
            }
        }
    }
}

@Composable
private fun ShareDialog(state: ShareUiState, model: ShareViewModel) {
    val naming = state.phase == SharePhase.NAMING
    AlertDialog(
        modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth().padding(horizontal = 16.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        onDismissRequest = model::close,
        title = { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(when (state.phase) {
            SharePhase.NAMING -> "本次任务设置"
            SharePhase.ERROR -> "未生成 ${state.container}"
            SharePhase.CANCELLING -> "正在取消"
            else -> "GPT Screenshot Pack"
            }, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            if (naming) Text("${state.inputCount} 张图片", style = MaterialTheme.typography.bodySmall)
        } },
        text = {
            // Scroll only as a fallback for small screens, large fonts, or the on-screen keyboard.
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (naming) {
                    OutlinedTextField(value = state.naming.base, onValueChange = model::editName,
                        label = { Text("文件名主体") }, singleLine = true,
                        suffix = {
                            val extension = ".${state.container.extension}"
                            if (!state.naming.base.endsWith(extension, ignoreCase = true)) Text(extension)
                        },
                        isError = state.error != null, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("自动附加日期时间", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = state.naming.appendDateTime, onCheckedChange = model::editDateTime)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("输出方式", style = MaterialTheme.typography.bodyMedium)
                        OutputContainer.entries.forEach { container ->
                            FilterChip(selected = state.container == container, onClick = { model.editContainer(container) },
                                label = { Text(container.name) }, modifier = Modifier.weight(1f))
                        }
                    }
                    if (state.container == OutputContainer.ZIP) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("格式", style = MaterialTheme.typography.bodyMedium)
                            listOf(OutputFormat.HEIC, OutputFormat.JPEG, OutputFormat.PNG).forEach { format ->
                                FilterChip(selected = state.format == format, onClick = { model.editFormat(format) },
                                    label = { Text(format.name) }, modifier = Modifier.weight(1f))
                            }
                        }
                    } else {
                        Text("每张图片一页 · JPEG 质量 ${state.pdfQuality}", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ResolutionOptions(state.resolutionMode, state.reducedScalePercent, state.scalePercentB, model::editResolutionMode)
                    if (state.resolutionMode == ResolutionMode.WIDTH)
                        TargetWidthField(state.targetWidth, model::editWidth, error = state.widthError)
                    Text("保存到 ${PackStorage.OUTPUT_PATH}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (state.phase != SharePhase.ERROR) {
                    Text(when (state.phase) {
                        SharePhase.LOADING -> "正在读取保存的设置…"
                        SharePhase.PREPARING -> "正在保存命名设置…"
                        SharePhase.PERMISSION -> "请允许保存到公共 Downloads"
                        SharePhase.CANCELLING -> "正在清理本次临时文件，已保存的文件保留。"
                        else -> "正在处理 ${state.done} / ${state.inputCount}；保存完成后自动退出。"
                    })
                    if (state.phase == SharePhase.PROCESSING)
                        LinearProgressIndicator(progress = { state.done.toFloat() / state.inputCount.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            if (naming) TextButton(onClick = model::confirm) { Text("开始处理") }
            else if (state.phase == SharePhase.ERROR) TextButton(onClick = model::close) { Text("关闭") }
        },
        dismissButton = {
            if (state.phase == SharePhase.ERROR && state.canRetry) TextButton(onClick = model::retry) { Text("修改设置") }
            else if (state.phase == SharePhase.ERROR) Unit
            else TextButton(onClick = model::close, enabled = state.phase != SharePhase.CANCELLING) { Text("取消") }
        },
    )
}
